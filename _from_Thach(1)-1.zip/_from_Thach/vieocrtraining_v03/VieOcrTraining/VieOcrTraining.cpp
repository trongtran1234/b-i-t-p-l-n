#include <iostream>
#include "VieOcrTraining.h"
#include <fstream>
#include <dirent.h>
#include <stdlib.h>

using namespace std;
using namespace cv;

#define ATTRIBUTES_PER_SAMPLE_1 168 // do dai vector dac trung, chu y thay doi theo pp trich dac trung
FILE * pFile;

string mode_training=""; // mode 1: training char, mode 2: training sign, mode 3: training vewel
string training_set_dir= "/home/dung/_from_Thach";
//string training_ver= "";

int main()
{
    string folder="";
    system("mkdir ./output && rm ./output/dactrung_ct_pb.txt");


            cout<<"-----   training char   -----"<<endl;
            folder="char";
            string svm_char_out_file="./output/svm_cph_char_common";
            training(folder,svm_char_out_file);// goi chuong trinh training



//    cout<<"*********************  Nhap mode training  *************************"<<endl;
//    cout<<"mode 1: training char, mode 2: training sign, mode 3: training vewel, mode all: training all"<<endl;
//    cout<<"Nhap mode :";

//    cin>>mode_training ;

//    if(mode_training=="1") {
//        cout<<"-----   training char   -----"<<endl;
//        folder="char";
//        string svm_char_out_file="./output/svm_cph_char_common_"+training_ver;
//        training(folder,svm_char_out_file);// goi chuong trinh training
//    } else if (mode_training=="2") {
//        cout<<"-----   training sign   -----"<<endl;
//        folder="sign";
//        string svm_sign_out_file="./output/svm_cph_sign_common_"+training_ver;
//        training(folder,svm_sign_out_file);// goi chuong trinh training
//    } else if (mode_training=="3") {
//        cout<<"-----   training vowel   -----"<<endl;
//        folder="vowel";
//        string svm_vowel_out_file="./output/svm_cph_vowel_common_"+training_ver;
//        training(folder,svm_vowel_out_file);// goi chuong trinh training
//    } else if (mode_training=="all") {

//        cout<<"-----   training char   -----"<<endl;
//        folder="char";
//        string svm_char_out_file="./output/svm_cph_char_common_"+training_ver;
//        training(folder,svm_char_out_file);// goi chuong trinh training

//        cout<<"-----   training sign   -----"<<endl;
//        folder="sign";
//        string svm_sign_out_file="./output/svm_cph_sign_common_"+training_ver;
//        training(folder,svm_sign_out_file);// goi chuong trinh training

//        cout<<"-----   training vowel   -----"<<endl;
//        folder="vowel";
//        string svm_vowel_out_file="./output/svm_cph_vowel_common_"+training_ver;
//        training(folder,svm_vowel_out_file);// goi chuong trinh training

//    } else {
//        cout<<"Chon sai mode. Vui long chay lai va nhap dung mode"<<endl;
//    }

    cout<<"*********************  Chu y: Kiem tra lai file svm  *************************"<<endl;

    return 0;
}

///////////////////////////////////////////////////////////////////////////////////
/////////////////////////training du lieu cho svm /////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////
void training(string training_folder, string file_out)
{

//    string training_dir= training_set_dir+"/"+training_ver+"/"+training_folder+"/";
    string training_dir= training_set_dir+"/"+training_folder+"/";
    DIR *dir;
    DIR *floder_dir;
    struct dirent *folder_dirent;
    struct dirent *ent;
    string file_name="";
    string folder_name="";
    pFile = fopen ("output/dactrung_ct_pb.txt","w");
    int NUMBER_OF_TRAINING_SAMPLES=0;   // bien dem tong so mau training
    int NUMBER_OF_CLASSES=0;            // so classes training

    if ((dir = opendir ((char*)training_dir.c_str())) != NULL) {

        /// xu ly voi tung folder trong thu muc training //
        while ((ent = readdir (dir)) != NULL) {
            if( strcmp(ent->d_name, ".") != 0 && strcmp(ent->d_name, "..") != 0 )
            {
                folder_name = training_dir+string(ent->d_name);
                NUMBER_OF_CLASSES++; // dem so classes tuong ung voi so folder
                int label = get_label(string(ent->d_name));// lay nhan cua folder

                cout<<"ten folder: "<<string(ent->d_name)<<endl;

                /// trich dac trung cac mau trong thu muc hien tai ///
                if ((floder_dir = opendir ((char*)folder_name.c_str())) != NULL) {

                    while ((folder_dirent = readdir (floder_dir)) != NULL) {
                        if( strcmp(folder_dirent->d_name, ".") != 0 && strcmp(folder_dirent->d_name, "..") != 0 )
                        {
                            file_name=folder_name+"/"+string(folder_dirent->d_name);
                            //cout<<file_name<<endl;
                            ext_contour_pf(file_name,label); //trich dac trung cua anh

                            NUMBER_OF_TRAINING_SAMPLES++; // dem so mau
                        }
                    }

                    closedir (floder_dir);
                }
            }
        }
        closedir (dir);

    } else {
        cout<<"/// could not open directory //"<<endl;

    }

    fclose (pFile);

    cout<<"NUMBER_OF_TRAINING_SAMPLES  :"<<NUMBER_OF_TRAINING_SAMPLES<<endl;
    cout<<"NUMBER_OF_CLASSES  :"<<NUMBER_OF_CLASSES<<endl;

    //// training du lieu svm ////

    Mat training_data_1 = Mat(NUMBER_OF_TRAINING_SAMPLES, ATTRIBUTES_PER_SAMPLE_1, CV_32FC1);// one row per feature
    Mat labels = Mat(NUMBER_OF_TRAINING_SAMPLES, 1, CV_32S);
    Ptr<ml::SVM> svm = ml::SVM::create();
    svm->setType(ml::SVM::C_SVC);
    svm->setKernel(ml::SVM::LINEAR);
    svm->setGamma(20);
    svm->setC(7);
    //svm->setClassWeights(0);
    svm->setNu(0);
    svm->setP(0);
    svm->setDegree(0);
    svm->setCoef0(0);
    svm->setTermCriteria(cv::TermCriteria(cv::TermCriteria::MAX_ITER +
                                          cv::TermCriteria::EPS,
                                          1000, // max number of iterations
                                          1e-6)); // min accuracy);

    if (read_dt_chutuyenplus("output/dactrung_ct_pb.txt", training_data_1, labels, NUMBER_OF_TRAINING_SAMPLES))
    {
        Ptr<ml::TrainData> tData = ml::TrainData::create(training_data_1,cv::ml::SampleTypes(0), labels);
        svm->train(tData);
        string file = "./output/svmout";
        svm->save(file);

        cout<<"hoan thanh training, data luu o ./output "<<endl;
    }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////trich dac trung chu tuyen ket hop bieu do chieu /////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////


int ext_contour_pf(string input_sample, int label)
{

    int a,b,c,d,e,f,flag;
    const char * input_char=(char*)input_sample.c_str();
    Mat gray_samp=imread(input_char,IMREAD_GRAYSCALE);
    if(!gray_samp.data){
        cout << "Error.No image input !" <<input_sample<<endl;
    }
    Mat gray_stand;
    resize(gray_samp ,gray_stand,Size(24, 32),0,0,INTER_CUBIC);
    Mat binary_samp(gray_stand);
    cv::threshold(gray_stand,binary_samp, 0, 255, CV_THRESH_OTSU+CV_THRESH_BINARY);
    //============= tu trai sang phai ============//

    for(int y=0;y<binary_samp.rows;y++)
    {
        a=0;
        flag=0;
        //cout<<"***********************************************"<<endl;
        for(int x=0;x<binary_samp.cols;x++)
        {
            a++;
            if((flag==0)&&(binary_samp.at<uchar>(y,x)==0))
            {
                //cout<<"gia tri trai phai "<<x<<":"<<y<<"la :"<<a<<endl;
                fprintf(pFile,"%d,",a);
                flag=1;
            }
            if ((flag==0)&&(x==binary_samp.cols-1)&&(binary_samp.at<uchar>(y,x)!=0))
            {
                fprintf(pFile,"%d,",a);
            }
        }
    }

    //============= tu phai sang trai ============//

    for(int y=0;y<binary_samp.rows;y++)
    {
        b=0;
        flag=0;
        //cout<<"***********************************************"<<endl;
        for(int x=binary_samp.cols-1;x>=0;x--)
        {
            b++;
            if((flag==0)&&(binary_samp.at<uchar>(y,x)==0))
            {
                //cout<<"gia tri trai phai "<<x<<":"<<y<<"la :"<<a<<endl;
                fprintf(pFile,"%d,",b);
                flag=1;
            }
            if ((flag==0)&&(x==0)&&(binary_samp.at<uchar>(y,x)!=0))
            {
                fprintf(pFile,"%d,",b);
            }
        }
    }

    //============= tu tren xuong duoi ============//

    for(int x=0;x<binary_samp.cols;x++)
    {
        c=0;
        flag=0;
        //cout<<"***********************************************"<<endl;
        for(int y=0;y<binary_samp.rows;y++)
        {
            c++;
            if((flag==0)&&(binary_samp.at<uchar>(y,x)==0))
            {
                //cout<<"gia tri trai phai "<<x<<":"<<y<<"la :"<<a<<endl;
                fprintf(pFile,"%d,",c);
                flag=1;
            }
            if ((flag==0)&&(y==binary_samp.rows-1)&&(binary_samp.at<uchar>(y,x)!=0))
            {
                fprintf(pFile,"%d,",c);
            }
        }
    }

    //============= tu duoi len tren ============//

    for(int x=0;x<binary_samp.cols;x++)
    {
        d=0;
        flag=0;
        //cout<<"***********************************************"<<endl;
        for(int y=binary_samp.rows-1;y>=0;y--)
        {
            d++;
            if((flag==0)&&(binary_samp.at<uchar>(y,x)==0))
            {
                //cout<<"gia tri trai phai "<<x<<":"<<y<<"la :"<<a<<endl;
                fprintf(pFile,"%d,",d);
                flag=1;
            }
            if ((flag==0)&&(y==0)&&(binary_samp.at<uchar>(y,x)!=0))
            {
                fprintf(pFile,"%d,",d);
            }
        }
    }
    //============= histogram ngang ============//

    for(int x=0;x<binary_samp.cols;x++)
    {
        e=0;
        //cout<<"***********************************************"<<endl;
        for(int y=0;y<binary_samp.rows;y++)
        {
            if(binary_samp.at<uchar>(y,x)==0)
            {
                e++;
            }
        }
        fprintf(pFile,"%d,",e);
    }
    //============= histogram doc ============//

    for(int y=0;y<binary_samp.rows;y++)
    {
        f=0;
        for(int x=0;x<binary_samp.cols;x++)
        {
            if(binary_samp.at<uchar>(y,x)==0)
            {
                f++;
            }
        }
        fprintf(pFile,"%d,",f);
    }

    fprintf(pFile,"%d",label);
    fprintf(pFile, "\n");


    return 0;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////// tra nhan cua classes de gan nhan cho training /////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////

int get_label(string in_value)
{
    int label=0;
    if (in_value=="A") {
        label=1;
    }
    if (in_value=="B") {
        label=2;
    }
    if (in_value=="C") {
        label=3;
    }
    if (in_value=="D") {
        label=4;
    }
    if (in_value=="E") {
        label=5;
    }
    if (in_value=="F") {
        label=6;
    }
    if (in_value=="G") {
        label=7;
    }
    if (in_value=="H") {
        label=8;
    }
    if (in_value=="I") {
        label=9;
    }
    if (in_value=="J") {
        label=10;
    }
    if (in_value=="K") {
        label=11;
    }
    if (in_value=="L") {
        label=12;
    }
    if (in_value=="M") {
        label=13;
    }
    if (in_value=="N") {
        label=14;
    }
    if (in_value=="O") {
        label=15;
    }
    if (in_value=="P") {
        label=16;
    }
    if (in_value=="Q") {
        label=17;
    }
    if (in_value=="R") {
        label=18;
    }
    if (in_value=="S") {
        label=19;
    }
    if (in_value=="T") {
        label=20;
    }
    if (in_value=="U") {
        label=21;
    }
    if (in_value=="V") {
        label=22;
    }
    if (in_value=="W") {
        label=23;
    }
    if (in_value=="X") {
        label=24;
    }
    if (in_value=="Y") {
        label=25;
    }
    if (in_value=="Z") {
        label=26;
    }
    if (in_value=="DD") {
        label=27;
    }
    if (in_value=="OW") {
        label=28;
    }
    if (in_value=="UW") {
        label=29;
    }
    if (in_value=="0") {
        label=30;
    }
    if (in_value=="1") {
        label=31;
    }
    if (in_value=="2") {
        label=32;
    }
    if (in_value=="3") {
        label=33;
    }
    if (in_value=="4") {
        label=34;
    }
    if (in_value=="5") {
        label=35;
    }
    if (in_value=="6") {
        label=36;
    }
    if (in_value=="7") {
        label=37;
    }
    if (in_value=="8") {
        label=38;
    }
    if (in_value=="9") {
        label=39;
    }
    if (in_value=="sac") {
        label=90;
    }
    if (in_value=="huyen") {
        label=91;
    }
    if (in_value=="hoi") {
        label=92;
    }
    if (in_value=="nga") {
        label=93;
    }
    if (in_value=="aw") {
        label=94;
    }
    if (in_value=="aa") {
        label=95;
    }
    if (in_value=="cham") {
        label=96;
    }
    return label;
}

/////////////////////////////////////////////////////////////////////////////////
///-doc file dac trung ghi du lieu ra ma tran data va mat tran label cho training svm-///
/////////////////////////////////////////////////////////////////////////////////

int read_dt_chutuyenplus(const char* filename, Mat data, Mat label, int n_samples)
{
    float tmp;
    int count=0;
    // if we can't read the input file then return 0
    FILE* f = fopen( filename, "r" );
    if( !f )
    {
        //qDebug("ERROR: cannot read data training");
    }
    // for each sample in the file
    for(int line = 0; line < n_samples; line++)
    {
        int count1=0;
        // for each attribute on the line in the file
        for(int attribute = 0; attribute < (ATTRIBUTES_PER_SAMPLE_1 + 1); attribute++)
        {
            if (attribute < ATTRIBUTES_PER_SAMPLE_1)
            {   count1++;
                fscanf(f, "%f,", &tmp);
                data.at<float>(line, attribute) = tmp;

            }
            else if (attribute == ATTRIBUTES_PER_SAMPLE_1)
            {
                count++;
                fscanf(f, "%f,", &tmp);
                int value=int(tmp);
                label.at<int>(line, 0) = value;
            }
        }
    }
    fclose(f);
    return 1;
}






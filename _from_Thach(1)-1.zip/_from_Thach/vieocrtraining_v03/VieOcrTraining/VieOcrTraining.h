#ifndef VIEOCRTRAINING_H
#define VIEOCRTRAINING_H

#endif // VIEOCRTRAINING_H

/////***** include opencv lib *****/////

#include <opencv2/highgui.hpp>
#include <opencv/ml.h>
#include <opencv/cv.h>
#include <opencv/cxcore.h>
#include <opencv2/imgproc.hpp>
//#include "opencv/types.hpp"

using namespace std;
using namespace cv;

int ext_contour_pf(string input_sample, int label);
int get_label(string in_value);
int read_dt_chutuyenplus(const char* filename, Mat data, Mat label, int n_samples);
void training (string training_folder, string file_out);
void trich_dac_trung(string input_sample, Mat data);

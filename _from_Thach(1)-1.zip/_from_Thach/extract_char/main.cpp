#include <iostream>
#include "extract_char.h"
#include <dirent.h>

/////***** include opencv lib *****/////

#include <opencv2/highgui.hpp>
#include <opencv/ml.h>
#include <opencv/cv.h>
#include <opencv/cxcore.h>
#include <opencv2/imgproc.hpp>

using namespace std;
using namespace cv;
string extract_dir="/home/thach253/Desktop/Thesis/Dropbox/thesis/test_set/input_image";


int main()
{
    string input;
    string folder_name;
    cout<<"Thu muc extract :"<<extract_dir<<endl;

    string cmd= "rm -rf "+extract_dir+"/output";
    system(cmd.c_str());

    cmd= "mkdir -p " + extract_dir+"/output";
    system(cmd.c_str());

    cmd= "ls " + extract_dir;
    system(cmd.c_str());

    cout << "chon option extract \n option: all ==> extract tat ca file trong thu muc ./image_input \n option: image_name.jpg ==> extract file  duoc chon \n";
    cout << "file in_put hoac all :" ;
    cin>>input ;
    if (input=="all") {
        cout<<"extract tat ca file trong thu muc ./image"<<endl;
        DIR *dir;
        struct dirent *ent;
        if ((dir = opendir (extract_dir.c_str())) != NULL) {
          /* print all the files and directories within directory */

            while ((ent = readdir (dir)) != NULL) {

              const char* file=ent->d_name;
              if( strcmp(ent->d_name, ".") != 0 && strcmp(ent->d_name, "..") != 0 && strcmp(ent->d_name, "output") != 0 ) {

                  folder_name=string(ent->d_name).substr(0,string(ent->d_name).length()-4);
                  cmd="mkdir -p " +extract_dir+"/output/"+folder_name;
                  system(cmd.c_str());
                  extract_char(file);
                  cout<<file<<endl;
              }
          }
          closedir (dir);
        } else {
          /* could not open directory */
          perror ("");
          return EXIT_FAILURE;
        }

    } else {

        folder_name=input.substr(0,input.length()-4);
        cmd="mkdir -p " +extract_dir+"/output/"+folder_name;
        system(cmd.c_str());
        extract_char(input);
        //cout<<"input  "<<input<<endl;
    }
}


int extract_char (std::string input_file) {

    /////***** Load Input Image *****/////

    const char* filename = NULL;
    string input_name=input_file.substr(0,input_file.length()-4);
    string str_temp=extract_dir+"/"+input_name+".jpg";
    filename = str_temp.c_str();
    Mat img_load = cv::imread(filename);
    if(!img_load.data){
        cout << "Error.No image input !" << endl;
    }
    /////***** RGB Image To Gray Image *****/////
    Mat img_gray, img_binary , img_binary_inv;
    cv::cvtColor(img_load,img_gray,CV_RGB2GRAY);
    /////***** Gray Image To Binary Image *****/////
    cv::threshold(img_gray, img_binary, 0, 255, CV_THRESH_OTSU+CV_THRESH_BINARY);
    cv::imwrite("img_binary.jpg",img_binary);
    cv::threshold(img_gray, img_binary_inv, 0, 255, CV_THRESH_OTSU+CV_THRESH_BINARY_INV);

    vector<vector<Point> > contours;
    //vector<Vec4i> hierarchy;
    cv::findContours(img_binary_inv,contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE);
    vector<Rect> boundRect( contours.size() );

    Mat img_word_in = cv::imread("img_binary.jpg");

    for( int i = 0; i < contours.size(); i++ )
    {
        boundRect[i] = boundingRect( Mat (contours[i]));

        /// loc kich thuoc contour
        if((boundRect[i].width>2)&&(boundRect[i].height>2)) {

            //Mat drawing = Mat::zeros (boundRect[i].size(), CV_8UC3);
            //drawContours( drawing, contours, i, Scalar(255,255,255), 1, 8, hierarchy, 0, Point() );

            Mat img_char = cv::Mat(img_word_in,boundRect[i]).clone();

            stringstream strs;
            strs << i;
            string out_dir =extract_dir+"/output/"+input_name+"/"+input_name+"_char_"+ strs.str() +".jpg";
            //cout<<""<<out_dir<<endl;
            char* char_name =(char*)out_dir.c_str();
            imwrite(char_name,img_char);
        }
    }

    cout<<"finished file: "<<filename<<endl;
    return 0;
}

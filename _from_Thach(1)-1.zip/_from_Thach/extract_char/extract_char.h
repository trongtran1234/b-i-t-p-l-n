#ifndef EXTRACT_CHAR_H
#define EXTRACT_CHAR_H

#endif // EXTRACT_CHAR_H


/////***** include opencv lib *****/////

#include <opencv2/highgui.hpp>
#include <opencv/ml.h>
#include <opencv/cv.h>
#include <opencv/cxcore.h>
#include <opencv2/imgproc.hpp>


int extract_char (std::string input_file );

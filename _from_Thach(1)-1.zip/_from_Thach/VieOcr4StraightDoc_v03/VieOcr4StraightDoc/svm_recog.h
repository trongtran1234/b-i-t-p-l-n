#ifndef SVM_RECOG_H
#define SVM_RECOG_H
#include "VieOcr.h"
#endif // SVM_RECOG_H

void trich_dac_trung(Mat binary_samp, Mat data);
int get_label(string in_value);
void write_file();
int recog_sign (Mat char_binary);
int recog_char (Mat char_binary);
int recog_vowel (Mat vowel_binary);

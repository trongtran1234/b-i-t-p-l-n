#ifndef EXTRACTION_H
#define EXTRACTION_H

#endif // EXTRACTION_H
#include <VieOcr.h>

int extract_line (cv::Mat img_binary);
int extract_word (cv::Mat img_line);
int extract_char (cv::Mat img_word);
int check_cnt_region (int position);

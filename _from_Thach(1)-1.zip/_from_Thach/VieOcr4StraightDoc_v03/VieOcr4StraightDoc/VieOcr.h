#ifndef VIEOCR_H
#define VIEOCR_H

#endif // VIEOCR_H
#include <iostream>
#include <math.h>
#include <fstream>
#include <dirent.h>
#include <stdlib.h>
//#include <tesseract/baseapi.h>
//#include <leptonica/allheaders.h>

/////***** include opencv lib *****/////

#include <opencv2/highgui.hpp>
#include <opencv/ml.h>
#include <opencv/cv.h>
#include <opencv/cxcore.h>
#include <opencv2/imgproc.hpp>

using namespace std;
using namespace cv;

#include "Border_Detection.h"
#include <iostream>
#include <math.h>


int IMG_HEIGHT=0;
int IMG_WIDTH=0;


int * Draw_Histogram(cv::Mat img_in,int mode){


   int IMG_HEIGHT=img_in.rows;
   int IMG_WIDTH=img_in.cols;

   int vHisto[IMG_WIDTH];
   int hHisto[IMG_HEIGHT];
/////////// mode 0: bieu do chieu doc , mode1 bieu do chieu ngang //////////
    if(mode==0){

        for(int x=0; x<IMG_WIDTH;x++){

            int vCount=0;
            for(int y=0; y<IMG_HEIGHT;y++){

                int t=img_in.at<uchar>(y,x);
                if(t==0) vCount++;
            }
            vHisto[x]=vCount;
            //cout<<"gia tri cua cot: "<<x<<" la :"<<vCount<<endl;
        }
        Mat vHistImage(IMG_HEIGHT, IMG_WIDTH, CV_8UC1, Scalar(255, 255, 255));


        // draw the intensity line for histogram
        for(int i = 0; i <IMG_WIDTH; i++)
        {
            line(vHistImage, Point(i, IMG_HEIGHT),Point(i, IMG_HEIGHT - vHisto[i]),Scalar(0,0,0), 1, 8, 0);
        }

        imwrite("vHisto.jpg",vHistImage);

        return vHisto;// tra ve gia tri mang bieu do chieu doc

    }else if(mode==1){

            for(int y=0; y<IMG_HEIGHT;y++){

                int hCount=0;
                for(int x=0; x<IMG_WIDTH;x++){

                    int t=img_in.at<uchar>(y,x);
                    if(t==0) hCount++;
                }
                hHisto[y]=hCount;
                //cout<<"gia tri cua cot: "<<y<<" la :"<<hCount<<endl;
        }

            Mat hHistImage(IMG_WIDTH, IMG_HEIGHT, CV_8UC1, Scalar(255, 255, 255));
             // draw the intensity line for histogram
            for(int i = 0; i < IMG_HEIGHT; i++)
            {
                line(hHistImage, Point(i, IMG_HEIGHT),Point(i, IMG_WIDTH - hHisto[i]),Scalar(0,0,0), 1, 8, 0);
            }

            imwrite("hHisto.jpg",hHistImage);

            return hHisto; // tra ve gia tri mang bieu do chieu ngang
    }
    return 0;
}



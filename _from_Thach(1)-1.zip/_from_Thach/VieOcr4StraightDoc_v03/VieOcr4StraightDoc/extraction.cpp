#include <iostream>
#include <string>
#include "extraction.h"
#include "Border_Detection.h"
#include "svm_recog.h"

#include <fstream>
#include <dirent.h>
#include <stdlib.h>

string line_name="";
string word_name="";
extern vector <int> result;
extern vector <int> cnt_regions;
extern int rst_count;


int extract_line (cv::Mat img_binary)
{
    int hei = img_binary.rows;
    int hHisto[hei];
    int wid = img_binary.cols;
    //int hHisto_average=0;
    int hHisto_total=0;

    for(int y=0; y<hei;y++){

            int hCount=0;
            for(int x=0; x<wid;x++){

                int t=img_binary.at<uchar>(y,x);
                if(t==0) hCount++;
            }
            hHisto[y]=hCount;
            hHisto_total=hHisto_total + hCount;
            //cout<<"gia tri cua dong: "<< y <<" la :"<<hCount<<endl;
     }
    // hHisto_average=hHisto_total/hei; //gia tri trung binh cua cac dong

    //////////////////////////////////////////////////////////
    //////////xac dinh so dong chu, do rong cua tung dong/////
    //////////khai bao cac bien de tach dong//////////////////
    int line_flag=1; // line_flag = 1, te xt line, line_flag=0 spacing bettween lines
    int line_hei [120] = {} ;    //do rong cua dong chu
    int start_line[120] = {} ;  //vi tri cua diem dau dong
    int num_line = 0;
    int line_threst =1 ;

    int row_value = hHisto[0];

    if (row_value>=line_threst)
    {
            line_flag = 1;
            start_line[num_line] = 0;
            line_hei[num_line] = 1;
    }
    for (int a=1;a<hei;a++)
    {
            row_value = hHisto[a];
            if ((row_value>line_threst)&&(line_flag==1))
            {
                    line_flag = 1;
                    line_hei[num_line]++;
            }
            if ((row_value > line_threst)&&(line_flag==0))
            {
                    line_flag = 1;
                    num_line++;
                    start_line[num_line] = a;
                    line_hei[num_line] = 1;

            }
            if (row_value < line_threst)
                    line_flag = 0;
    }

    /////////////////////////////////////////////////////
    //////////tach cac dong chu trong anh////////////////
    /////////////////////////////////////////////////////
    //cout<<"tong so dong la :  "<<num_line<<endl;

    for (int i=0; i<num_line+1; i++)
    {
        //cout<<"do cao dong  "<<i<<"la :"<<line_hei[i]<<endl;
        if (line_hei[i]>10)
        {
            cv::Mat img_line = cv::Mat(img_binary, cv::Rect(0,start_line[i],wid,line_hei[i])).clone();
            stringstream strs;
            strs << i;
            line_name = "output/image/line_"+strs.str();
            //cout<<"xu ly dong chu : "<<line_name<<endl;
            string str_temp= line_name+".jpg";
            cv::imwrite(str_temp,img_line);
            extract_word(img_line);
            result[rst_count]=99;//ky tu danh dau xuong dong
            cnt_regions[rst_count]=1;
            rst_count++;
            //cout<<"--------- tach xong dong chu ------------"<<strs.str()<<endl;
        }

    }
return 0;
}

int extract_word (cv::Mat img_line)
{
    int line_width = img_line.cols;
    int line_height = img_line.rows;
    int vHisto[line_width];
    cv::Mat img_word;

    for(int x=0; x<line_width;x++)
    {
        int vCount=0;
        for(int y=0; y<line_height;y++){

            int t=img_line.at<uchar>(y,x);
            if(t==0) vCount++;
        }
        vHisto[x]=vCount;
    }

    //    /////////////////////////////////////////////////
    //    ///////xac dinh so chu, do rong cua tung chu/////
    //    /////////////////////////////////////////////////

    int flag,col_value;
    int space_width[3000];
    int start_space[3000];
    int num_of_space = 0;
    start_space[num_of_space]= 0;
    space_width[num_of_space]= 0;
    int word_thres = 2;

    col_value = vHisto[0];
    if (col_value<word_thres)
    {
        flag = 0;
        space_width[num_of_space]++;
    }
    else
    {
        space_width[num_of_space]= 0;
        flag = 1;
        num_of_space++;
    }
    for (int a=1;a<line_width;a++)
    {
        col_value = vHisto[a];
        if ((col_value<word_thres)&(flag==0))
        {
            flag = 0;
            space_width[num_of_space]++;
        }
        if ((col_value>=word_thres)&(flag==0))
        {
            flag = 1;
            num_of_space++;
            space_width[num_of_space]=0;
            start_space[num_of_space]=a;
        }
        if ((col_value>=word_thres)&(flag==1))
        {
            flag = 1;
            start_space[num_of_space]=a;
        }
        if ((col_value<word_thres)&(flag==1))
        {
            flag = 0;
            start_space[num_of_space]=a;
            space_width[num_of_space]++;
        }

    }
    ////////////////////////////////////
    //////// tach cac chu //////////////
    ////////////////////////////////////
    //==xac dinh do rong khoang trang==//
    int space_width_total = 0;
    int space_width_arvage = 0;

    if (num_of_space>1)
    {
        for(int j=1;j<num_of_space;j++)
        {
            space_width_total = space_width_total + space_width[j];
        }
        space_width_arvage = space_width_total/(num_of_space-1);
    }
    else if (num_of_space == 1)
    {
        space_width_total = 0;
    }
    else
    {
        cout<<"khong co chu"<<endl;
    }

    ///////xac dinh lai so khoang trang//////
    int num_space = 0;
    int length_space[50];
    int begin_space[50];
    length_space[0] = space_width[0];
    begin_space[0] = start_space[0];
    if (num_of_space>1)
    {
        for(int j=1;j<num_of_space;j++)
        {
            if (space_width[j]>=space_width_arvage+5)
            {
                num_space++;
                length_space[num_space] = space_width[j];
                begin_space[num_space] = start_space[j];
            }
        }
        num_space++;
        length_space[num_space] = space_width[num_of_space];
        begin_space[num_space] = start_space[num_of_space];
    }
    else if (num_of_space == 1)
    {
        num_space++;
        length_space[num_space] = space_width[num_of_space];
        begin_space[num_space] = start_space[num_of_space];
    }
    else
    {
        cout<<"khong co chu"<<endl;
    }

    //////////////////////////////////////////
    ////////////thuc hien tach chu////////////

    if (num_space > 1)
    {
        for(int j=1;j<num_space+1;j++)
        {
            int word_width = begin_space[j]-begin_space[j-1]-length_space[j-1];

            if (word_width > 5)
            {
                img_word = cv::Mat(img_line, cv::Rect(begin_space[j-1]+length_space[j-1],0,word_width,line_height)).clone();
                stringstream strs;
                strs << j;
                word_name =line_name+ "word_"+strs.str();
                string temp_str =word_name + ".jpg";
                cv::imwrite(temp_str,img_word);
                //----- bat dau tach chu va nhan dang -----"
                extract_char(img_word);

                result[rst_count]=98; //ky tu danh dau space
                cnt_regions[rst_count]=1;
                rst_count++;
                img_word.release();
            }

        }

    }
    else if (num_space == 1)
    {
        int word_width = begin_space[1]-begin_space[0]-length_space[0];
        img_word = cv::Mat(img_line, cv::Rect(begin_space[0]+length_space[0],0,word_width,line_height)).clone();
        cv::imwrite("ouput/image/word_0.jpg",img_word);
        extract_char(img_word);

        result[rst_count]=98; //ky tu danh dau space
        cnt_regions[rst_count]=1;
        rst_count++;
        img_word.release();
    }


    return num_space;
}

int extract_char(cv::Mat img_word)
{
    vector<vector<Point> > contours;
    Mat img_word_inv;
    Mat img_word_copy=img_word.clone();
    cv::threshold(img_word_copy, img_word_inv, 0, 255, CV_THRESH_OTSU+CV_THRESH_BINARY_INV);
 //   medianBlur(img_word_inv,img_word_inv,7);
 //   imwrite("img_word_inv.jpg",img_word_inv);
    cv::findContours(img_word_inv,contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE);
    vector<Rect> rect_cc( contours.size() );
    vector<Rect> rect_char( contours.size() );
    vector<Rect> rect_char_copy( contours.size() );
    vector<Mat> img_char( contours.size());
    int num_of_char=0;

    /////////// tim contour trong word //////////

    for( int i = 0; i< contours.size(); i++ )
    {
        rect_cc[i] = boundingRect( Mat (contours[i]));
        if (rect_cc[i].width>0 && rect_cc[i].height>0) {
            rect_char[i] = rect_cc[i];
            //cout<<"toa do rect_char[i].x "<<rect_char[i].x<<endl;
            num_of_char++;
        } else {
           // cout<<"nhieu"<<endl;
        }
    }

    ///////////// sort contours by x ///////////

    for(int i=0;i<num_of_char;i++)
    {
        for(int temp=i+1;temp<num_of_char;temp++)
        {
            if (rect_char[i].x>=rect_char[temp].x)
            {
                vector<Rect> rect_temp(1);
                rect_temp[0]=rect_char[i];
                rect_char[i]=rect_char[temp];
                rect_char[temp]=rect_temp[0];
            }
        }
    }

    for(int i=0;i<num_of_char;i++) {
            rect_char_copy[i]=rect_char[i];
            //cout<<"toa do rect_char[i].x "<<rect_char[i].x<<endl;
        }
    ///////////// tim kiem va sap xep lai vung lien thong ///////////

    int so_lien_ket=0;
    int cnt_reigion_position=0;
    int cnt_reigion_position_pre=0;
    vector<int> phan_loai(num_of_char,1); // 1: 1 vung lien thong, 2: 2 vung lien thong, 3: 3 vung lien thong.
    vector<Rect> vung_lien_thong(100);
    char cnt_region_pre_flag=0;
    char cnt_region_flag=0;
    int xi=0 ,xr=0 ; // xr: x right
    int xn =0; // xrn: right next
    int xp =0,xrp=0; // xrn: x right previous
    int connect_result=0; //0 ko co lien ket, 1 lien ket voi dung truoc, 2 lien ket voi pt dung sau.

    for(int i=0;i<num_of_char;i++) {

        ///******* tim lien ket*************///

        cnt_region_pre_flag=cnt_region_flag; // error free() invalid pointer
        cnt_reigion_position_pre=cnt_reigion_position;

        xi=rect_char[i].x;
        xr=rect_char[i].x+rect_char[i].width;

        // position = 0 chi kiem tra lien ket voi ky tu tiep theo
        if (i==0) {

            xn=rect_char[i+1].x;
            if ((xn>=xi)&&(xn<xr))
            {
                connect_result=2;
            }

            // postion = num_of_char : ky tu cuoi ; chi kiem tra lien ket voi ky tu o truoc.
        } else if (i==num_of_char-1) {

            xp=rect_char[i-1].x;
            xrp=rect_char[i-1].x+rect_char[i-1].width;

            if (((xi>=xp)&&(xi<xrp)))
            {
                connect_result=1;
            }else {
                connect_result=0;
            }
            // phan con lai kiem tra lien ket voi ky tu o truoc va sau.
        } else {

            xn=rect_char[i+1].x;
            xp=rect_char[i-1].x;
            xrp=rect_char[i-1].x+rect_char[i-1].width;

            if (((xi>=xp)&&(xi<xrp))) // lien ket voi pt truoc
            {
                connect_result=1;
            } else if (((xn>=xi)&&(xn<xr)))  // lien ket voi pt sau
            {
                connect_result=2;
            } else {
                connect_result=0;
                cnt_region_flag=0;
            }
        }


        if (connect_result==2) {
            cnt_reigion_position=i;
            cnt_region_flag=1;
            if (cnt_region_pre_flag==0) {
                so_lien_ket=1;
                vung_lien_thong[so_lien_ket]=rect_char[i];
            }
        } else if (connect_result==1) {
            so_lien_ket++;
            vung_lien_thong[so_lien_ket]=rect_char[i];
            cnt_region_flag=1;
        }


       // cout<<"connect_result :"<<connect_result<<endl;

        if(((i==num_of_char-1)&&(cnt_region_flag==1))||((connect_result!=1)&&(cnt_region_pre_flag==1))) {

            //cout<<"ket qua phan loai==> So lien ket :"<<so_lien_ket<<"  Vi tri lien ket "<<cnt_reigion_position_pre<<endl;
            // sap xep theo chieu y
            for(int j=1;j<so_lien_ket+1;j++)
            {
                for(int temp=j+1;temp<so_lien_ket+1;temp++)
                {
                    if ( vung_lien_thong[j].y< vung_lien_thong[temp].y)
                    {
                        vector<Rect> rect_temp(1);
                        rect_temp[0]=vung_lien_thong[j];
                        vung_lien_thong[j]=vung_lien_thong[temp];
                        vung_lien_thong[temp]=rect_temp[0];
                    }
                }
            }

            //copy phan lien thoong da sap xep vao mang bang dau
           // cout<<"vi tri lien ket :"<<cnt_reigion_position_pre<<"  so lien ket :"<<so_lien_ket<<endl;
            int k=1;
            for(int j=cnt_reigion_position_pre;j<cnt_reigion_position_pre+so_lien_ket;j++)
            {
                rect_char_copy[j]=vung_lien_thong[k];
                k++;
            }

            // phan loai dau va nguyen am
                if(vung_lien_thong[1].width*vung_lien_thong[1].height<vung_lien_thong[2].width*vung_lien_thong[2].height)
                {
                   // cout<<"dau nang"<<endl;
                    phan_loai[cnt_reigion_position_pre]=0;
                    phan_loai[cnt_reigion_position_pre+1]=2;
                    for(int j=cnt_reigion_position_pre+2;j<cnt_reigion_position_pre+so_lien_ket;j++)
                    {
                        phan_loai[j]=3;
                    }

                } else{
                    phan_loai[cnt_reigion_position_pre]=2;
                    for(int j=cnt_reigion_position_pre+1;j<cnt_reigion_position_pre+so_lien_ket;j++)
                    {
                        phan_loai[j]=3;
                    }
                }

            //reset cac co

            if (connect_result==2&&cnt_region_pre_flag==1) {
               so_lien_ket=1;
               vung_lien_thong[so_lien_ket]=rect_char[i];
            }
            cnt_region_flag=0;
        }
    }

//////////////////nhan dang//////////////////


for(int i=0;i<num_of_char;i++) {
        img_char[i]=cv::Mat(img_word_copy,rect_char_copy[i]).clone();
        stringstream strs;
        strs <<i;
        string temp_str =word_name + "char_a"+ strs.str() +".jpg";

        imwrite(temp_str,img_char[i]);

    }

//cout<<"num_of_char :"<<num_of_char<<endl;

////*****************  nhan dang **********************//

    for ( int i=0; i<num_of_char; i++) {

        resize(img_char[i] ,img_char[i],Size(24, 32),0,0,INTER_LINEAR);
        if(phan_loai[i]==0) {
            result[rst_count]=0;
            cnt_regions[rst_count]=so_lien_ket;

        }
        if(phan_loai[i]==1) {
            result[rst_count]=recog_char(img_char[i]);
            cnt_regions[rst_count]=1;

        }
        if(phan_loai[i]==2) {
            result[rst_count]=recog_vowel(img_char[i]);
            cnt_regions[rst_count]=so_lien_ket;

        }
        if(phan_loai[i]==3) {
            result[rst_count]=recog_sign(img_char[i]);
            cnt_regions[rst_count]=so_lien_ket;

        }

       // cout <<"result[rst_count] "<<result[rst_count]<<endl;
        rst_count++;
        img_char[i].release();

   }
    img_word.release();
    //cout<<"******** nhan dang xong chu"<<endl;

    return 1;
}


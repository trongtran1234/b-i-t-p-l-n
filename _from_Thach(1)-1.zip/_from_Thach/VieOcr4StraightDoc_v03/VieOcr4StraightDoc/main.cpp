
#include <iostream>
#include <VieOcr.h>
#include "Border_Detection.h"
#include "extraction.h"
#include "svm_recog.h"

string input; // duong dan folder chua document can nhan dang
vector <int> result(2000); // vector luu ket qua nhan dang toan bo document
vector <int> cnt_regions(2000,1);//connected regions. vector danh dau vung lien thong--- 1: 1 vung lt, 2: 2 vung lt, 3: 3 vung lt
int rst_count=0; // bien dem cua mang result


int main()
{

    /////***** Load Input Image *****/////
    const char* filename = NULL;
    system("rm -rf output/image ");
    system("mkdir -p input && mkdir -p output && mkdir -p output/image");
    system("ls test/*.jpg");

    cout << "nhap ten file : ";
    cin>>input ;
    input="test/"+input;

    //input="output/image/line_2word_16.jpg";
    cout << "File can chuyen: " << input << endl ;
    filename = input.c_str();
    Mat img_load = cv::imread(filename);
    if(!img_load.data){
        cout << "Error.No image input !" << endl;
    }
    /////***** RGB Image To Gray Image *****/////

    Mat img_gray;
    cv::cvtColor(img_load,img_gray,CV_RGB2GRAY);
    //cv::imshow("img_gray",img_gray);

    /////***** Gray Image To Binary Image *****/////
    Mat img_binary;
    cv::threshold(img_gray, img_binary, 0, 255, CV_THRESH_OTSU+CV_THRESH_BINARY);
    cv::imwrite("output/image/img_binary.jpg",img_binary);

    //    cv::imshow("img_binary",img_binary);
    //    cout<<"bat dau nhan dang"<<endl;
         extract_line (img_binary);
    //    cout<<"nhan dang xong"<<endl;
    //     extract_word(img_binary);

//    extract_char(img_binary);

//        for(int i=0;i<rst_count;i++)
//    {
//        cout<<"ket qua nhan dang thu   "<<i<<"la : "<<result[i]<<" : "<<cnt_regions[i]<<endl;
//    }

     write_file();

     system("vi ./output/result.txt");

    cout << "** so phan tu *** :" <<rst_count<<endl;
    cout << "**********************************done**********************************" << endl;
    //waitKey(0);                                          // Wait for a keystroke in the window


    return 0;
}



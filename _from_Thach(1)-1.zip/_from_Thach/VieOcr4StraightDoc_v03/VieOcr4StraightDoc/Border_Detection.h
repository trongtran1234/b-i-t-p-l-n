#ifndef BORDER_DETECTION_H
#define BORDER_DETECTION_H

#endif // BORDER_DETECTION_H
#include "VieOcr.h"

int * Draw_Histogram(cv::Mat img_in,int mode);


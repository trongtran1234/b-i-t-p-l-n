#include <VieOcr.h>
#include <svm_recog.h>


//

string svm_dir="input";
string svm_ver="common_training_set_v04";
string feature_extraction_ver ="cph";

// khai bao va load data svm

string svm_char_dir=svm_dir+"/svm_"+feature_extraction_ver+"_char_"+svm_ver;
Ptr<ml::SVM> svm_char = ml::StatModel::load<ml::SVM>(svm_char_dir);

string svm_sign_dir=svm_dir+"/svm_"+feature_extraction_ver+"_sign_"+svm_ver;
Ptr<ml::SVM> svm_sign = ml::StatModel::load<ml::SVM>(svm_sign_dir);

string svm_vowel_dir=svm_dir+"/svm_"+feature_extraction_ver+"_vowel_"+svm_ver;
Ptr<ml::SVM> svm_vowel = ml::StatModel::load<ml::SVM>(svm_vowel_dir);



extern int rst_count;
extern vector <int> result;
extern vector <int> cnt_regions;

int recog_sign (Mat char_binary)
{
//    Ptr<ml::SVM> svm_sign= ml::SVM::create();
//    svm_sign = ml::SVM::load<ml::SVM>("input/svm_sign.txt");
    Mat testMat(1, 168, CV_32FC1);
    trich_dac_trung(char_binary, testMat);
    //cout<<testMat<<endl;
    float result =1000;
    result = svm_sign->predict(testMat);
    //cout<<"ket qua la:"<<result<<endl;
    return int(result);
}
int recog_char (Mat char_binary)
{
 /*   Ptr<ml::SVM> svm_char = ml::SVM::create();
    svm_char = ml::SVM::load<ml::SVM>("input/svm_char.txt")*/;
    Mat testMat(1, 168, CV_32FC1);
    trich_dac_trung(char_binary, testMat);
    //cout<<testMat<<endl;
    float result =1000;
    result = svm_char->predict(testMat);
    //cout<<"ket qua la:"<<result<<endl;
    return int(result);
}

int recog_vowel (Mat vowel_binary)
{
//    Ptr<ml::SVM> svm_vowel = ml::SVM::create();
//    svm_vowel = ml::SVM::load<ml::SVM>("input/svm_vowel.txt");
    Mat testMat(1, 168, CV_32FC1);
    trich_dac_trung(vowel_binary, testMat);
    //cout<<testMat<<endl;
    float result =1000;
    result = svm_vowel->predict(testMat);
    //cout<<"ket qua la:"<<result<<endl;
    return int(result);
}

///////////////////////////////////////////////////////////////////

void trich_dac_trung(Mat binary_samp, Mat data)
{

    int a,b,c,d,e,f,flag;
    int attribute=0;

 //============= tu trai sang phai ============//
    for(int y=0;y<binary_samp.rows;y++)
    {
        a=0;
        flag=0;
        //cout<<"***********************************************"<<endl;
        for(int x=0;x<binary_samp.cols;x++)
        {
            a++;
            if((flag==0)&&(binary_samp.at<uchar>(y,x)==0))
            {
                data.at<float>(0,attribute)=a;
                flag=1;
            }
            if ((flag==0)&&(x==binary_samp.cols-1)&&(binary_samp.at<uchar>(y,x)!=0))
            {
                data.at<float>(0,attribute)=a;
            }

        }
        attribute++;
    }

    //============= tu phai sang trai ============//

    for(int y=0;y<binary_samp.rows;y++)
    {
        b=0;
        flag=0;
        //cout<<"***********************************************"<<endl;
        for(int x=binary_samp.cols-1;x>=0;x--)
        {
            b++;
            if((flag==0)&&(binary_samp.at<uchar>(y,x)==0))
            {
                data.at<float>(0,attribute)=b;
                flag=1;
            }
            if ((flag==0)&&(x==0)&&(binary_samp.at<uchar>(y,x)!=0))
            {
                data.at<float>(0,attribute)=b;
            }
        }
        attribute++;
    }

    //============= tu tren xuong duoi ============//

    for(int x=0;x<binary_samp.cols;x++)
    {
        c=0;
        flag=0;
        //cout<<"***********************************************"<<endl;
        for(int y=0;y<binary_samp.rows;y++)
        {
            c++;
            if((flag==0)&&(binary_samp.at<uchar>(y,x)==0))
            {
                data.at<float>(0,attribute)=c;
                flag=1;
            }
            if ((flag==0)&&(y==binary_samp.rows-1)&&(binary_samp.at<uchar>(y,x)!=0))
            {
                data.at<float>(0,attribute)=c;
            }
        }
        attribute++;
    }

    //============= tu duoi len tren ============//

    for(int x=0;x<binary_samp.cols;x++)
    {
        d=0;
        flag=0;
        //cout<<"***********************************************"<<endl;
        for(int y=binary_samp.rows-1;y>=0;y--)
        {
            d++;
            if((flag==0)&&(binary_samp.at<uchar>(y,x)==0))
            {
                data.at<float>(0,attribute)=d;
                flag=1;
            }
            if ((flag==0)&&(y==0)&&(binary_samp.at<uchar>(y,x)!=0))
            {
                data.at<float>(0,attribute)=d;
            }
        }
        attribute++;
    }
    //============= histogram ngang ============//

    for(int x=0;x<binary_samp.cols;x++)
    {
        e=0;
        //cout<<"***********************************************"<<endl;
        for(int y=0;y<binary_samp.rows;y++)
        {
            if(binary_samp.at<uchar>(y,x)==0)
            {
                e++;
             }
        }
        data.at<float>(0,attribute)=e;
        attribute++;
    }
    //============= histogram doc ============//

    for(int y=0;y<binary_samp.rows;y++)
    {
        f=0;
        for(int x=0;x<binary_samp.cols;x++)
        {
            if(binary_samp.at<uchar>(y,x)==0)
            {
                f++;
             }
        }
        data.at<float>(0,attribute)=f;
        attribute++;
    }
}

int get_label(string in_value)
{
    int label;

    if (in_value=="a") {
        label=1;
    }
    if (in_value=="b") {
        label=2;
    }
    if (in_value=="c") {
        label=3;
    }
    if (in_value=="d") {
        label=4;
    }
    if (in_value=="e") {
        label=5;
    }
    if (in_value=="f") {
        label=6;
    }
    if (in_value=="g") {
        label=7;
    }
    if (in_value=="h") {
        label=8;
    }
    if (in_value=="i") {
        label=9;
    }
    if (in_value=="j") {
        label=10;
    }
    if (in_value=="k") {
        label=11;
    }
    if (in_value=="l") {
        label=12;
    }
    if (in_value=="m") {
        label=13;
    }
    if (in_value=="n") {
        label=14;
    }
    if (in_value=="o") {
        label=15;
    }
    if (in_value=="p") {
        label=16;
    }
    if (in_value=="q") {
        label=17;
    }
    if (in_value=="r") {
        label=18;
    }
    if (in_value=="s") {
        label=19;
    }
    if (in_value=="t") {
        label=20;
    }
    if (in_value=="u") {
        label=21;
    }
    if (in_value=="v") {
        label=22;
    }
    if (in_value=="w") {
        label=23;
    }
    if (in_value=="x") {
        label=24;
    }
    if (in_value=="y") {
        label=25;
    }
    if (in_value=="z") {
        label=26;
    }
    if (in_value=="dd") {
        label=27;
    }
    if (in_value=="ow") {
        label=28;
    }
    if (in_value=="uw") {
        label=29;
    }
    if (in_value=="0") {
        label=30;
    }
    if (in_value=="1") {
        label=31;
    }
    if (in_value=="2") {
        label=32;
    }
    if (in_value=="3") {
        label=33;
    }
    if (in_value=="4") {
        label=34;
    }
    if (in_value=="5") {
        label=35;
    }
    if (in_value=="6") {
        label=36;
    }
    if (in_value=="7") {
        label=37;
    }
    if (in_value=="8") {
        label=38;
    }
    if (in_value=="9") {
        label=39;
    }
    return label;
}

void write_file() {

    const char* encodedString;
    encodedString = "";
    FILE * pFile = fopen ("output/result.txt","w");
    for (int i= 0; i<rst_count;i++)
    {
//        cout<<"phan loai ket qua:"<<int(cnt_regions[i])<<endl;
//        cout<<"gia tri ket qua:"<<int(result[i])<<endl;
        switch (int(cnt_regions[i]))
        {

        case 1:
            encodedString = "";
            if(result[i]==98) {
                encodedString = " ";
            }
            if(result[i]==99) {
                encodedString = "\n";
            }

            if (result[i]==1) {
                encodedString = "a";
            }
            if (result[i]==2) {
                encodedString = "b";
            }
            if (result[i]==3) {
                encodedString = "c";
            }
            if (result[i]==4) {
                encodedString = "d";
            }
            if (result[i]==5) {
                encodedString = "e";
            }
            if (result[i]==6) {
                encodedString = "f";
            }
            if (result[i]==7) {
                encodedString = "g";
            }
            if (result[i]==8) {
                encodedString = "h";
            }
//            if (result[i]==9) {
//                encodedString = "i";
//            }
//            if (result[i]==10) {
//                encodedString = "j";
//            }
            if (result[i]==11) {
                encodedString = "k";
            }
            if (result[i]==12) {
                encodedString = "l";
            }
            if (result[i]==13) {
                encodedString = "m";
            }
            if (result[i]==14) {
                encodedString = "n";
            }
            if (result[i]==15) {
                encodedString = "o";
            }
            if (result[i]==16) {
                encodedString = "p";
            }
            if (result[i]==17) {
                encodedString = "q";
            }
            if (result[i]==18) {
                encodedString = "r";
            }
            if (result[i]==19) {
                encodedString = "s";
            }
            if (result[i]==20) {
                encodedString = "t";
            }
            if (result[i]==21) {
                encodedString = "u";
            }
            if (result[i]==22) {
                encodedString = "v";
            }
            if (result[i]==23) {
                encodedString = "w";
            }
            if (result[i]==24) {
                encodedString = "x";
            }
            if (result[i]==25) {
                encodedString = "y";
            }
            if (result[i]==26) {
                encodedString = "z";
            }
            if (result[i]==27) {
                encodedString = "đ";
            }
            if (result[i]==28) {
                encodedString = "ơ";
            }
            if (result[i]==29) {
                encodedString = "ư";
            }
            if (result[i]==30) {
                encodedString = "0";
            }
            if (result[i]==31) {
                encodedString = "1";
            }
            if (result[i]==32) {
                encodedString = "2";
            }
            if (result[i]==33) {
                encodedString = "3";
            }
            if (result[i]==34) {
                encodedString = "4";
            }
            if (result[i]==35) {
                encodedString = "5";
            }
            if (result[i]==36) {
                encodedString = "6";
            }
            if (result[i]==37) {
                encodedString = "7";
            }
            if (result[i]==38) {
                encodedString = "8";
            }
            if (result[i]==39) {
                encodedString = "9";
            }
            break;
        case 2:
            encodedString = "";
            if (result[i]==0) {

                if (result[i+1]==1) {
                    encodedString = "ạ";
                }
                if (result[i+1]==5) {
                    encodedString = "ẹ";
                }
//                if (result[i+1]==9) {
//                    encodedString = "ị";
//                }
                if (result[i+1]==15) {
                    encodedString = "ọ";
                }
                if (result[i+1]==28) {
                    encodedString = "ợ";
                }
                if (result[i+1]==21) {
                    encodedString = "ụ";
                }
                if (result[i+1]==29) {
                    encodedString = "ự";
                }
                if (result[i+1]==25) {
                    encodedString = "ỵ";
                }
            } else {
                if (result[i]==1) {
                    encodedString = "a";

                    if (result[i+1]==95) {
                        encodedString = "â";
                    }
                    if (result[i+1]==95) {
                        encodedString = "ă";
                    }
                    if (result[i+1]==91) {
                        encodedString = "à";
                    }
                    if (result[i+1]==90) {
                        encodedString = "á";
                    }
                    if (result[i+1]==92) {
                        encodedString = "ả";
                    }
                    if (result[i+1]==93) {
                        encodedString = "ã";
                    }
                }

                if (result[i]==5) {
                    encodedString = "e";
                    if (result[i]==91) {
                        encodedString = "è";
                    }
                    if (result[i]==90) {
                        encodedString = "é";
                    }
                    if (result[i+1]==92) {
                        encodedString = "ẻ";
                    }
                    if (result[i+1]==93) {
                        encodedString = "ẽ";
                    }
                    if (result[i+1]==95) {
                        encodedString = "ê";
                    }
                }

                if (result[i]==9) {
                    encodedString = "i";
//                    if (result[i+1]==91) {
//                        encodedString = "ì";
//                    }
//                    if (result[i+1]==90) {
//                        encodedString = "í";
//                    }
//                    if (result[i+1]==92) {
//                        encodedString = "ỉ";
//                    }
//                    if (result[i+1]==93) {
//                        encodedString = "ĩ";
//                    }
                }
                if (result[i]==15) {

                    encodedString = "o";

                    if (result[i+1]==91) {
                        encodedString = "ò";
                    }
                    if (result[i+1]==90) {
                        encodedString = "ó";
                    }
                    if (result[i+1]==92) {
                        encodedString = "ỏ";
                    }
                    if (result[i+1]==93) {
                        encodedString = "õ";
                    }
                    if (result[i+1]==95) {
                        encodedString = "ô";
                    }
                }
                if (result[i]==28) {
                    if (result[i+1]==91) {
                        encodedString = "ờ";
                    }
                    if (result[i+1]==90) {
                        encodedString = "ớ";
                    }
                    if (result[i+1]==92) {
                        encodedString = "ở";
                    }
                    if (result[i+1]==93) {
                        encodedString = "ỡ";
                    }
                }
                if (result[i]==21) {

                    encodedString = "u";
                    if (result[i+1]==91) {
                        encodedString = "ù";
                    }
                    if (result[i+1]==90) {
                        encodedString = "ú";
                    }
                    if (result[i+1]==92) {
                        encodedString = "ủ";
                    }
                    if (result[i+1]==93) {
                        encodedString = "ũ";
                    }
                }
                if (result[i]==29) {

                    encodedString = "ư";
                    if (result[i+1]==91) {
                        encodedString = "ừ";
                    }
                    if (result[i+1]==90) {
                        encodedString = "ứ";
                    }
                    if (result[i+1]==92) {
                        encodedString = "ử";
                    }
                    if (result[i+1]==93) {
                        encodedString = "ữ";
                    }
                }
                if (result[i]==25) {

                    encodedString = "y";
                    if (result[i+1]==91) {
                        encodedString = "ỳ";
                    }
                    if (result[i+1]==90) {
                        encodedString = "ý";
                    }
                    if (result[i+1]==92) {
                        encodedString = "ỷ";
                    }
                    if (result[i+1]==93) {
                        encodedString = "ỹ";
                    }
                }

            }
            i=i+1;
            break;

        case 3:
            encodedString = "";
            if (result[i]==0) {

                encodedString = "a";

                if (result[i+1]==1&&result[i+2]==95) {
                    encodedString = "ậ";
                }
                if (result[i+1]==1&&result[i+2]==94) {
                    encodedString = "ặ";
                }
                if (result[i+1]==5&&result[i+2]==95) {
                    encodedString = "ệ";
                }
                if (result[i+1]==15&&result[i+2]==95) {
                    encodedString = "ộ";
                }
            } else {
                if (result[i]==1) {
                    encodedString = "a";
                    if (result[i+1]==95) {
                        if (result[i+2]==91) {
                            encodedString = "ầ";
                        }
                        if (result[i+2]==90) {
                            encodedString = "ấ";
                        }
                        if (result[i+2]==92) {
                            encodedString = "ẩ";
                        }
                        if (result[i+2]==93) {
                            encodedString = "ẫ";
                        }
                    }
                    if (result[i+1]==94) {
                        if (result[i+2]==91) {
                            encodedString = "ằ";
                        }
                        if (result[i+2]==90) {
                            encodedString = "ắ";
                        }
                        if (result[i+2]==92) {
                            encodedString = "ẳ";
                        }
                        if (result[i+2]==93) {
                            encodedString = "ẵ";
                        }

                    }
                }
                if (result[i]==5&&result[i+1]==95) {

                    encodedString = "ê";
                    if (result[i+2]==91) {
                        encodedString = "ề";
                    }
                    if (result[i+2]==90) {
                        encodedString = "ế";
                    }
                    if (result[i+2]==92) {
                        encodedString = "ể";
                    }
                    if (result[i+2]==93) {
                        encodedString = "ễ";
                    }
                }
                if (result[i]==15&&result[i+1]==95) {

                    encodedString = "ô";
                    if (result[i+2]==91) {
                        encodedString = "ồ";
                    }
                    if (result[i+2]==90) {
                        encodedString = "ố";
                    }
                    if (result[i+2]==92) {
                        encodedString = "ổ";
                    }
                    if (result[i+2]==93) {
                        encodedString = "ỗ";
                    }
                }

            }
            i=i+2;
            break;
        }
        fprintf(pFile,encodedString);
    }
        fclose (pFile);
}
